function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(60, 90, 200);
  fill(194, 178, 128)
  noStroke()
  rect(0, 320, 400, 80)
  stroke(0)
  fill(20,90,30)
  triangle(200, 200, 200, 280, 120, 240)
  noFill()
  noFill()
  fill(30,20,90)
  ellipse(80, 240, 120, 80)
  fill(200, 200, 200)
  ellipse(50, 240,30, 30)
   fill(0)
  ellipse(45, 240,20, 20)
  //second fish
   fill(200,90,30)
  triangle(0, 50, 0, 120, 120, 80)
  noFill()
  noFill()
  fill(200,20,90)
  ellipse(100, 80, 120, 80)
  fill(200, 200, 200)
  ellipse(130, 80,30, 30)
   fill(0)
  ellipse(135, 80,20, 20)
  fill(200,90,30)
  triangle(100,100,70,80,100,80)
  
}